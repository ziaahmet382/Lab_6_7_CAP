"""Start/stop all three localhost gRPC replicas for demos, tests and benchmarks."""
from __future__ import annotations

import subprocess
import sys
import time
from contextlib import contextmanager
from pathlib import Path

import grpc

from server import PORTS
import kvstore_pb2 as pb
import kvstore_pb2_grpc as rpc

ROOT = Path(__file__).resolve().parent


def store(node: str):
    return rpc.KeyValueStoreStub(grpc.insecure_channel(f"127.0.0.1:{PORTS[node]}"))


def control(node: str):
    return rpc.ReplicaControlStub(grpc.insecure_channel(f"127.0.0.1:{PORTS[node]}"))


def partition(isolate_c: bool):
    for node in PORTS:
        control(node).SetPartition(pb.PartitionRequest(isolate_c=isolate_c), timeout=1.0)


@contextmanager
def running_cluster():
    processes = []
    try:
        for node in PORTS:
            process = subprocess.Popen(
                [sys.executable, str(ROOT / "server.py"), "--node", node],
                cwd=ROOT,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            processes.append(process)
        for node, port in PORTS.items():
            channel = grpc.insecure_channel(f"127.0.0.1:{port}")
            grpc.channel_ready_future(channel).result(timeout=8)
        time.sleep(0.4)
        yield
    finally:
        for process in processes:
            process.terminate()
        for process in processes:
            try:
                process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=2)

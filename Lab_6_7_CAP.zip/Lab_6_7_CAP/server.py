"""Three-node educational gRPC KV store for Lab 6-7.

CP writes require a leader and 2/3 acknowledgments; AP writes are local.
Partitions are simulated at the RPC application layer for reproducible tests.
This is a *teaching simulator*, not a production consensus implementation.
"""
from __future__ import annotations

import argparse
import logging
import threading
import time
from concurrent import futures
from dataclasses import dataclass

import grpc

import kvstore_pb2 as pb
import kvstore_pb2_grpc as rpc

PORTS = {"A": 50051, "B": 50052, "C": 50053}
LEADER = "A"
RPC_TIMEOUT = 0.25


def clock_ms() -> int:
    return time.time_ns() // 1_000_000


@dataclass(frozen=True)
class Value:
    value: str
    timestamp: int
    origin: str

    @property
    def version(self):
        return self.timestamp, self.origin


class KeyValueNode(rpc.KeyValueStoreServicer, rpc.ReplicaControlServicer):
    def __init__(self, node: str):
        if node not in PORTS:
            raise ValueError(f"Unknown node: {node}")
        self.node = node
        self._data: dict[str, Value] = {}
        self._lock = threading.RLock()
        self._stop = threading.Event()
        self._isolate_c = False
        self._last_seen_leader_ms = clock_ms()
        self._last_timestamp = 0
        self._idempotent: dict[str, pb.PutReply] = {}
        self._gossip_thread = None

    def _reachable(self, other: str) -> bool:
        with self._lock:
            isolated = self._isolate_c
        return not (isolated and ((self.node == "C") != (other == "C")))

    @staticmethod
    def _channel(other: str):
        return grpc.insecure_channel(f"127.0.0.1:{PORTS[other]}")

    def _control(self, other: str):
        return rpc.ReplicaControlStub(self._channel(other))

    def _merge(self, key: str, proposed: Value) -> None:
        with self._lock:
            current = self._data.get(key)
            if current is None or proposed.version > current.version:
                self._data[key] = proposed
            self._last_timestamp = max(self._last_timestamp, proposed.timestamp)

    def _snapshot(self):
        with self._lock:
            return [pb.Entry(key=k, value=v.value, timestamp=v.timestamp, origin=v.origin)
                    for k, v in self._data.items()]

    def _get_value(self, key: str):
        with self._lock:
            return self._data.get(key)

    def _next_timestamp(self, requested: int) -> int:
        with self._lock:
            self._last_timestamp = max(self._last_timestamp + 1, clock_ms(), requested)
            return self._last_timestamp

    def _majority_reachable(self) -> bool:
        acknowledgments = 1
        for peer in PORTS:
            if peer == self.node or not self._reachable(peer):
                continue
            try:
                if self._control(peer).Ping(pb.PingRequest(sender=self.node), timeout=RPC_TIMEOUT).ok:
                    acknowledgments += 1
            except grpc.RpcError:
                pass
        return acknowledgments >= 2

    def Get(self, request: pb.GetRequest, context) -> pb.GetReply:
        if request.consistency == pb.LINEARIZABLE:
            if self.node != LEADER:
                if not self._reachable(LEADER):
                    context.abort(grpc.StatusCode.UNAVAILABLE, "LEASEHOLDER_UNAVAILABLE")
                try:
                    return rpc.KeyValueStoreStub(self._channel(LEADER)).Get(
                        request, timeout=2.0)
                except grpc.RpcError as error:
                    context.abort(error.code(), error.details())
            if not self._majority_reachable():
                context.abort(grpc.StatusCode.UNAVAILABLE, "READ_QUORUM_LOST")
        elif request.consistency == pb.FOLLOWER_STALE and self.node != LEADER:
            with self._lock:
                age_ms = clock_ms() - self._last_seen_leader_ms
            if age_ms > request.max_staleness_ms:
                context.abort(grpc.StatusCode.FAILED_PRECONDITION, "STALE_READ_EXCEEDED")

        value = self._get_value(request.key)
        if value is None:
            return pb.GetReply(found=False, is_stale=(request.consistency == pb.FOLLOWER_STALE and self.node != LEADER))
        return pb.GetReply(value=value.value, found=True, read_timestamp=value.timestamp,
                           is_stale=(request.consistency == pb.FOLLOWER_STALE and self.node != LEADER))

    def Put(self, request: pb.PutRequest, context) -> pb.PutReply:
        if request.strategy == pb.ALWAYS_AP:
            timestamp = self._next_timestamp(request.timestamp)
            self._merge(request.key, Value(request.value, timestamp, self.node))
            return pb.PutReply(success=True, acks_received=1)

        if self.node != LEADER:
            if not self._reachable(LEADER):
                return pb.PutReply(success=False, acks_received=0,
                                   error_message="QUORUM_LOST: cannot reach leaseholder")
            try:
                return rpc.KeyValueStoreStub(self._channel(LEADER)).Put(request, timeout=2.0)
            except grpc.RpcError as error:
                return pb.PutReply(success=False, acks_received=0,
                                   error_message=f"QUORUM_LOST: {error.details()}")

        with self._lock:
            if request.idempotency_key and request.idempotency_key in self._idempotent:
                return self._idempotent[request.idempotency_key]

        timestamp = self._next_timestamp(request.timestamp)
        value = Value(request.value, timestamp, LEADER)
        entry = pb.Entry(key=request.key, value=value.value,
                         timestamp=value.timestamp, origin=value.origin)
        acks = 1  # Leader counts as one ACK only when the write can commit.
        for peer in PORTS:
            if peer == LEADER or not self._reachable(peer):
                continue
            try:
                if self._control(peer).ApplyReplica(pb.ReplicaWrite(entry=entry), timeout=RPC_TIMEOUT).ok:
                    acks += 1
            except grpc.RpcError:
                pass
        if acks < 2:
            return pb.PutReply(success=False, acks_received=acks,
                               error_message="QUORUM_LOST: need at least 2 of 3 ACKs")
        self._merge(request.key, value)
        reply = pb.PutReply(success=True, acks_received=acks)
        if request.idempotency_key:
            with self._lock:
                self._idempotent[request.idempotency_key] = reply
        return reply

    def ApplyReplica(self, request: pb.ReplicaWrite, context) -> pb.Ack:
        e = request.entry
        self._merge(e.key, Value(e.value, e.timestamp, e.origin))
        if e.origin == LEADER:
            with self._lock:
                self._last_seen_leader_ms = clock_ms()
        return pb.Ack(ok=True)

    def SetPartition(self, request: pb.PartitionRequest, context) -> pb.Ack:
        with self._lock:
            self._isolate_c = request.isolate_c
        logging.info("Node %s: partition enabled=%s", self.node, request.isolate_c)
        return pb.Ack(ok=True)

    def Ping(self, request: pb.PingRequest, context) -> pb.Ack:
        if request.sender == LEADER:
            with self._lock:
                self._last_seen_leader_ms = clock_ms()
        return pb.Ack(ok=True)

    def SyncSnapshot(self, request: pb.SnapshotRequest, context) -> pb.SnapshotReply:
        for entry in request.entries:
            self._merge(entry.key, Value(entry.value, entry.timestamp, entry.origin))
        return pb.SnapshotReply(entries=self._snapshot())

    def _gossip(self):
        while not self._stop.wait(0.20):
            for peer in PORTS:
                if peer == self.node or not self._reachable(peer):
                    continue
                try:
                    stub = self._control(peer)
                    if self.node == LEADER:
                        stub.Ping(pb.PingRequest(sender=LEADER), timeout=RPC_TIMEOUT)
                    response = stub.SyncSnapshot(
                        pb.SnapshotRequest(entries=self._snapshot()), timeout=RPC_TIMEOUT)
                    for entry in response.entries:
                        self._merge(entry.key, Value(entry.value, entry.timestamp, entry.origin))
                except grpc.RpcError:
                    continue

    def start_gossip(self):
        self._gossip_thread = threading.Thread(target=self._gossip, daemon=True)
        self._gossip_thread.start()

    def stop(self):
        self._stop.set()
        if self._gossip_thread:
            self._gossip_thread.join(timeout=1.0)


def main():
    parser = argparse.ArgumentParser(description="Educational distributed gRPC KV-store")
    parser.add_argument("--node", choices=list(PORTS), required=True)
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")
    service = KeyValueNode(args.node)
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=24))
    rpc.add_KeyValueStoreServicer_to_server(service, server)
    rpc.add_ReplicaControlServicer_to_server(service, server)
    port = PORTS[args.node]
    if server.add_insecure_port(f"127.0.0.1:{port}") != port:
        raise RuntimeError(f"Failed to bind port {port}")
    server.start()
    service.start_gossip()
    print(f"Node {args.node} running on 127.0.0.1:{port} (leader={LEADER})", flush=True)
    try:
        server.wait_for_termination()
    except KeyboardInterrupt:
        pass
    finally:
        service.stop()
        server.stop(grace=0.5)


if __name__ == "__main__":
    main()

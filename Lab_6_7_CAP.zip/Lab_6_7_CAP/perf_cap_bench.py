"""Task 4: 1000 sequential gRPC reads for EACH of two read modes."""
from __future__ import annotations

import json
import statistics
import time
from pathlib import Path

import grpc
import kvstore_pb2 as pb
from cluster import running_cluster, store

ROOT = Path(__file__).resolve().parent
ITERATIONS = 1000


def benchmark(stub, request):
    elapsed_ms = []
    ok = 0
    for _ in range(ITERATIONS):
        start = time.perf_counter_ns()
        try:
            reply = stub.Get(request, timeout=2)
            if reply.found:
                ok += 1
        except grpc.RpcError:
            pass
        elapsed_ms.append((time.perf_counter_ns() - start) / 1_000_000)
    durations = sorted(elapsed_ms)
    return {
        "iterations": ITERATIONS,
        "successful_reads": ok,
        "median_ms": round(statistics.median(durations), 4),
        "p95_ms": round(durations[int((len(durations) - 1) * 0.95)], 4),
        "availability_pct": round(ok * 100 / ITERATIONS, 2),
    }


def main():
    with running_cluster():
        response = store("A").Put(pb.PutRequest(
            key="bench", value="hello", strategy=pb.QUORUM_CP), timeout=3)
        assert response.success, "Could not seed cluster"
        time.sleep(0.25)
        scenarios = {
            "linearizable": benchmark(store("A"), pb.GetRequest(
                key="bench", consistency=pb.LINEARIZABLE)),
            "follower_stale": benchmark(store("B"), pb.GetRequest(
                key="bench", consistency=pb.FOLLOWER_STALE, max_staleness_ms=5000)),
        }
    (ROOT / "bench_results.json").write_text(json.dumps(scenarios, indent=2), encoding="utf-8")
    print("\nTask 4: PACELC measurements (your actual localhost run)")
    print("Mode                 Median ms   p95 ms    Availability")
    for name, measured in scenarios.items():
        print(f"{name:20} {measured['median_ms']:9.4f} {measured['p95_ms']:9.4f} "
              f"{measured['availability_pct']:8.2f}%")
    print("Saved bench_results.json")


if __name__ == "__main__":
    main()

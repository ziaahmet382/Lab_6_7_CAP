"""Build an English PDF lab report from real demo, test and benchmark results."""
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, KeepTogether

ROOT = Path(__file__).resolve().parent


def load(name):
    path = ROOT / name
    if not path.exists():
        raise SystemExit(f"Missing {name}: run 'python run_all.py' first")
    return json.loads(path.read_text(encoding="utf-8"))


def main():
    demonstration = load("demo_results.json")
    performance = load("bench_results.json")
    tests = load("test_results.json")
    output = ROOT / "Lab_Report_CAP.pdf"
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="TitleCustom", parent=styles["Title"], fontSize=17, leading=23,
                              textColor=colors.HexColor("#123456"), spaceAfter=12))
    styles.add(ParagraphStyle(name="SmallCustom", parent=styles["Normal"], fontSize=9, leading=13,
                              spaceAfter=6))
    styles.add(ParagraphStyle(name="CenterTiny", fontName="Helvetica", fontSize=8, leading=11,
                              alignment=TA_CENTER))
    doc = SimpleDocTemplate(str(output), pagesize=A4, rightMargin=1.7 * cm,
                            leftMargin=1.7 * cm, topMargin=1.6 * cm, bottomMargin=1.6 * cm)
    story = []
    small = lambda t: Paragraph(t, styles["SmallCustom"])
    story.append(Paragraph("Lab 6-7: Consistency Models &amp; the CAP Theorem", styles["TitleCustom"]))
    story.append(small("CSS4004 - Distributed Systems | Measured on localhost | " + datetime.now().strftime("%Y-%m-%d %H:%M")))
    story.append(small("Architecture: Python/gRPC, 3 independent processes (A:50051 leader; B:50052 and C:50053 followers). This educational simulator emulates network partitions at the application RPC level."))

    story.append(Paragraph("1. Test Results &amp; Quorum Verification", styles["Heading2"]))
    major = demonstration["cp_majority"]
    minor = demonstration["cp_minority"]
    ap = demonstration["ap_minority"]
    recover = demonstration["after_recovery"]
    rows = [
        ["Experiment", "Expected", "Observed"],
        ["CP, majority A+B", "2 ACK; accepted", f"success={major['success']}, ACKs={major['acks_received']}"],
        ["CP, minority C", "Rejected", f"success={minor['success']}, ACKs={minor['acks_received']}"],
        ["AP, minority C", "1 ACK; accepted", f"success={ap['success']}, ACKs={ap['acks_received']}"],
        ["Recovery with LWW", "Newest wins", "converged=" + str(recover["all_nodes_converged"])],
    ]
    table = Table(rows, colWidths=[5 * cm, 5 * cm, 5.5 * cm], repeatRows=1)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#DFE9F2")),
        ("GRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#ABB9C4")),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("TOPPADDING", (0, 0), (-1, -1), 7),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
    ]))
    story.append(table)
    story.append(Spacer(1, 0.2 * cm))
    story.append(small(f"Automated pytest suite: <b>{tests['passed']} passed</b>, {tests['failed']} failed. "
                       "Tests cover majority/minority writes, AP behavior, LWW recovery, linearizable routing, staleness rejection, and minority reads."))

    story.append(Paragraph("2. PACELC Performance Evaluation", styles["Heading2"]))
    rows = [["Read mode", "Target", "Median (ms)", "p95 (ms)", "Read availability"]]
    for name, label, target in [
        ("linearizable", "LINEARIZABLE", "Leader A"),
        ("follower_stale", "FOLLOWER_STALE", "Follower B"),
    ]:
        r = performance[name]
        rows.append([label, target, str(r["median_ms"]), str(r["p95_ms"]),
                     f"{r['availability_pct']}%"])
    table2 = Table(rows, colWidths=[3.5 * cm, 2.8 * cm, 2.8 * cm, 2.6 * cm, 3.8 * cm], repeatRows=1)
    table2.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#DFE9F2")),
        ("GRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#ABB9C4")),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 7.5),
        ("TOPPADDING", (0, 0), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
    ]))
    story.append(table2)
    story.append(Spacer(1, 0.2 * cm))
    story.append(small("Each scenario executes 1,000 sequential Get requests against the same 3-node localhost cluster. Median is the 50th percentile; p95 captures the latency below which approximately 95% of observations fall. Availability is successful reads divided by attempted reads."))

    story.append(Paragraph("3. Conceptual Questions", styles["Heading2"]))
    story.append(small("<b>Q1. Why is R + W &gt; N important?</b> When R + W &gt; N, read and write quorums must overlap in at least one replica, so a read can discover a previously acknowledged write. When R + W &lt;= N, they may be disjoint, allowing a read to return an older value. This overlap is necessary for many quorum-based strong-consistency designs but does not, by itself, guarantee linearizability: correct ordering, version selection, and concurrent-write handling are also required."))
    story.append(small("<b>Q2. CP vs AP during minority network partitions?</b> In QUORUM_CP, node C cannot contact the leader or reach a majority and therefore rejects the write. The system prioritizes consistency over availability for C. In ALWAYS_AP, node C accepts a local write with one acknowledgment, preserving write availability but allowing temporary divergence. Once the partition heals, background anti-entropy exchanges replicas' values and LWW (the highest timestamp, with a deterministic origin tie-breaker) resolves conflicts."))
    story.append(Paragraph("Implementation notes", styles["Heading3"]))
    story.append(small("This is a minimal lab simulator, not a production consensus implementation. The partition flag blocks inter-group outbound RPCs rather than creating a real network failure. CP write replication is simplified (no Raft, durable log, prepare/commit transactions or crash-safe acknowledgments). Follower freshness is approximated by time since last leader heartbeat, rather than a formally guaranteed bounded-staleness protocol. Benchmark outcomes depend on localhost scheduling and hardware."))

    doc.build(story)
    print("Saved Lab_Report_CAP.pdf")


if __name__ == "__main__":
    main()

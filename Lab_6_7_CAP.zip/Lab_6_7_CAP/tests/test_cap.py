"""Real subprocess-based three-node CP/AP tests (>=6 required)."""
from __future__ import annotations

import time
import uuid

import grpc
import pytest

import kvstore_pb2 as pb
from cluster import partition, running_cluster, store


@pytest.fixture(scope="module", autouse=True)
def nodes():
    with running_cluster():
        yield


@pytest.fixture(autouse=True)
def heal_after_test():
    partition(False)
    yield
    partition(False)


def key(prefix):
    return f"{prefix}-{uuid.uuid4().hex}"


def eventually(condition, seconds=3.0):
    end = time.monotonic() + seconds
    while time.monotonic() < end:
        if condition():
            return
        time.sleep(0.07)
    assert condition(), "Expected eventual convergence before timeout"


def read(node, k, mode=pb.LINEARIZABLE, age=5000):
    return store(node).Get(pb.GetRequest(
        key=k, consistency=mode, max_staleness_ms=age), timeout=2)


def put(node, k, value, strategy=pb.QUORUM_CP, timestamp=0):
    return store(node).Put(pb.PutRequest(
        key=k, value=value, strategy=strategy, timestamp=timestamp,
        idempotency_key=f"{k}-{value}"), timeout=2)


def test_01_majority_cp_write_succeeds():
    """A+B form a majority after isolating C."""
    partition(True)
    result = put("A", key("majority"), "OK")
    assert result.success and result.acks_received == 2


def test_02_minority_cp_write_fails():
    partition(True)
    result = put("C", key("minority"), "REJECT")
    assert not result.success and result.acks_received == 0
    assert "QUORUM_LOST" in result.error_message


def test_03_minority_ap_write_accepted():
    partition(True)
    k = key("ap")
    result = put("C", k, "AVAILABLE", strategy=pb.ALWAYS_AP)
    assert result.success and result.acks_received == 1
    assert read("C", k, pb.FOLLOWER_STALE, age=5000).value == "AVAILABLE"


def test_04_lww_recovery_after_partition():
    k = key("merge")
    partition(True)
    earlier = int(time.time() * 1000) + 1000
    later = earlier + 1000
    cp = put("A", k, "OLD", timestamp=earlier)
    ap = put("C", k, "NEW", strategy=pb.ALWAYS_AP, timestamp=later)
    assert cp.success and ap.success
    assert read("A", k).value == "OLD"
    partition(False)
    eventually(lambda: read("A", k).value == "NEW")
    eventually(lambda: read("B", k, pb.FOLLOWER_STALE).value == "NEW")
    eventually(lambda: read("C", k, pb.FOLLOWER_STALE).value == "NEW")


def test_05_linearizable_read_proxies_to_leader():
    k = key("leader")
    assert put("A", k, "LEADER").success
    assert read("B", k, pb.LINEARIZABLE).value == "LEADER"
    assert not read("B", k, pb.LINEARIZABLE).is_stale


def test_06_follower_staleness_limit_rejected():
    partition(True)
    time.sleep(0.16)
    with pytest.raises(grpc.RpcError) as exc:
        read("C", key("old"), pb.FOLLOWER_STALE, age=50)
    assert exc.value.code() == grpc.StatusCode.FAILED_PRECONDITION
    assert "STALE_READ_EXCEEDED" in exc.value.details()


def test_07_minority_linearizable_read_fails():
    partition(True)
    with pytest.raises(grpc.RpcError) as exc:
        read("C", key("hidden"), pb.LINEARIZABLE)
    assert exc.value.code() == grpc.StatusCode.UNAVAILABLE


def test_08_lww_keeps_latest_timestamp_when_recovered():
    k = key("winner")
    partition(True)
    base = int(time.time() * 1000) + 1000
    assert put("C", k, "WINNER", pb.ALWAYS_AP, timestamp=base + 1000).success
    assert put("A", k, "LOSER", pb.QUORUM_CP, timestamp=base).success
    partition(False)
    eventually(lambda: read("A", k).value == "WINNER")

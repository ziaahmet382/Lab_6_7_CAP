"""Run practical CAP scenarios and save their actually observed results."""
from __future__ import annotations

import json
import time
import uuid
from pathlib import Path

import kvstore_pb2 as pb
from cluster import partition, running_cluster, store

ROOT = Path(__file__).resolve().parent


def wait_for_value(node, key, expected, timeout=4.0):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        result = store(node).Get(pb.GetRequest(key=key, consistency=pb.FOLLOWER_STALE,
                                              max_staleness_ms=5000), timeout=2)
        if result.found and result.value == expected:
            return True
        time.sleep(0.08)
    return False


def main():
    marker = uuid.uuid4().hex[:8]
    quorum_key = "quorum-" + marker
    merge_key = "merge-" + marker
    with running_cluster():
        partition(True)
        major = store("A").Put(pb.PutRequest(key=quorum_key, value="majority", strategy=pb.QUORUM_CP), timeout=3)
        minor = store("C").Put(pb.PutRequest(key="minority-" + marker, value="rejected", strategy=pb.QUORUM_CP), timeout=3)
        ap = store("C").Put(pb.PutRequest(key=merge_key, value="new-from-C", strategy=pb.ALWAYS_AP,
                                               timestamp=int(time.time() * 1000) + 3000), timeout=3)
        cp = store("A").Put(pb.PutRequest(key=merge_key, value="old-from-A", strategy=pb.QUORUM_CP,
                                               timestamp=int(time.time() * 1000) + 1000), timeout=3)
        partition(False)
        healed = all(wait_for_value(node, merge_key, "new-from-C") for node in ["A", "B", "C"])
        result = {
            "cp_majority": {"success": major.success, "acks_received": major.acks_received},
            "cp_minority": {"success": minor.success, "acks_received": minor.acks_received,
                            "error_message": minor.error_message},
            "ap_minority": {"success": ap.success, "acks_received": ap.acks_received},
            "cp_old_value": {"success": cp.success, "acks_received": cp.acks_received},
            "after_recovery": {"all_nodes_converged": healed, "winner": "new-from-C" if healed else "not converged"},
        }
        assert major.success and major.acks_received == 2
        assert not minor.success
        assert ap.success and ap.acks_received == 1
        assert cp.success and healed
        (ROOT / "demo_results.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
        print("Scenario results:")
        for scenario, measurements in result.items():
            print(f"  {scenario}: {measurements}")
        print("Saved demo_results.json")


if __name__ == "__main__":
    main()

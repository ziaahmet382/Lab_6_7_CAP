"""Command-line manual experiments; start each server.py in a separate terminal."""
from __future__ import annotations

import argparse
import grpc

import kvstore_pb2 as pb
from cluster import control, partition, store


def main():
    parser = argparse.ArgumentParser(description="KV store CLI")
    sub = parser.add_subparsers(dest="cmd", required=True)
    put = sub.add_parser("put")
    put.add_argument("--node", choices=["A", "B", "C"], default="A")
    put.add_argument("--key", required=True)
    put.add_argument("--value", required=True)
    put.add_argument("--strategy", choices=["cp", "ap"], default="cp")
    get = sub.add_parser("get")
    get.add_argument("--node", choices=["A", "B", "C"], default="A")
    get.add_argument("--key", required=True)
    get.add_argument("--mode", choices=["linearizable", "stale"], default="linearizable")
    get.add_argument("--max-staleness-ms", type=int, default=5000)
    pt = sub.add_parser("partition")
    pt.add_argument("--mode", choices=["on", "off"], required=True)
    args = parser.parse_args()
    try:
        if args.cmd == "put":
            response = store(args.node).Put(pb.PutRequest(
                key=args.key, value=args.value,
                strategy=pb.QUORUM_CP if args.strategy == "cp" else pb.ALWAYS_AP), timeout=3)
            print(f"success={response.success} acks={response.acks_received} error={response.error_message or 'none'}")
        elif args.cmd == "get":
            response = store(args.node).Get(pb.GetRequest(
                key=args.key, consistency=pb.LINEARIZABLE if args.mode == "linearizable" else pb.FOLLOWER_STALE,
                max_staleness_ms=args.max_staleness_ms), timeout=3)
            print(f"found={response.found} value={response.value!r} timestamp={response.read_timestamp} is_stale={response.is_stale}")
        elif args.cmd == "partition":
            partition(args.mode == "on")
            print(f"Network partition C | A,B: {args.mode}")
    except grpc.RpcError as error:
        print(f"RPC error: {error.code().name}: {error.details()}")
        raise SystemExit(1)


if __name__ == "__main__":
    main()

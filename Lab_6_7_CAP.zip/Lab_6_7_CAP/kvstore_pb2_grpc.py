"""gRPC stubs and service registration for kvstore.proto."""
import grpc
import kvstore_pb2 as pb


class KeyValueStoreStub:
    def __init__(self, channel):
        self.Get = channel.unary_unary(
            "/kvstore.KeyValueStore/Get", request_serializer=pb.GetRequest.SerializeToString,
            response_deserializer=pb.GetReply.FromString)
        self.Put = channel.unary_unary(
            "/kvstore.KeyValueStore/Put", request_serializer=pb.PutRequest.SerializeToString,
            response_deserializer=pb.PutReply.FromString)


class KeyValueStoreServicer:
    def Get(self, request, context):
        raise NotImplementedError()

    def Put(self, request, context):
        raise NotImplementedError()


def add_KeyValueStoreServicer_to_server(service, server):
    handlers = {
        "Get": grpc.unary_unary_rpc_method_handler(
            service.Get, request_deserializer=pb.GetRequest.FromString,
            response_serializer=pb.GetReply.SerializeToString),
        "Put": grpc.unary_unary_rpc_method_handler(
            service.Put, request_deserializer=pb.PutRequest.FromString,
            response_serializer=pb.PutReply.SerializeToString),
    }
    server.add_generic_rpc_handlers((grpc.method_handlers_generic_handler("kvstore.KeyValueStore", handlers),))


class ReplicaControlStub:
    def __init__(self, channel):
        self.ApplyReplica = channel.unary_unary(
            "/kvstore.ReplicaControl/ApplyReplica", request_serializer=pb.ReplicaWrite.SerializeToString,
            response_deserializer=pb.Ack.FromString)
        self.SetPartition = channel.unary_unary(
            "/kvstore.ReplicaControl/SetPartition", request_serializer=pb.PartitionRequest.SerializeToString,
            response_deserializer=pb.Ack.FromString)
        self.Ping = channel.unary_unary(
            "/kvstore.ReplicaControl/Ping", request_serializer=pb.PingRequest.SerializeToString,
            response_deserializer=pb.Ack.FromString)
        self.SyncSnapshot = channel.unary_unary(
            "/kvstore.ReplicaControl/SyncSnapshot", request_serializer=pb.SnapshotRequest.SerializeToString,
            response_deserializer=pb.SnapshotReply.FromString)


class ReplicaControlServicer:
    def ApplyReplica(self, request, context):
        raise NotImplementedError()

    def SetPartition(self, request, context):
        raise NotImplementedError()

    def Ping(self, request, context):
        raise NotImplementedError()

    def SyncSnapshot(self, request, context):
        raise NotImplementedError()


def add_ReplicaControlServicer_to_server(service, server):
    endpoints = {
        "ApplyReplica": (service.ApplyReplica, pb.ReplicaWrite, pb.Ack),
        "SetPartition": (service.SetPartition, pb.PartitionRequest, pb.Ack),
        "Ping": (service.Ping, pb.PingRequest, pb.Ack),
        "SyncSnapshot": (service.SyncSnapshot, pb.SnapshotRequest, pb.SnapshotReply),
    }
    handlers = {
        name: grpc.unary_unary_rpc_method_handler(
            func, request_deserializer=request_type.FromString,
            response_serializer=reply_type.SerializeToString)
        for name, (func, request_type, reply_type) in endpoints.items()
    }
    server.add_generic_rpc_handlers((grpc.method_handlers_generic_handler("kvstore.ReplicaControl", handlers),))

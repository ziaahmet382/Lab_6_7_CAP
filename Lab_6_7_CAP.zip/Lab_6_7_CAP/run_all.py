"""One-click walkthrough: 8 pytest cases -> CAP demo -> benchmarks -> PDF report."""
from __future__ import annotations

import json
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def run(script):
    print("\n" + "=" * 60, flush=True)
    print(f"> python {script}", flush=True)
    subprocess.run([sys.executable, str(ROOT / script)], cwd=ROOT, check=True)


def main():
    print("\nSTEP 1/4 - Eight automated tests", flush=True)
    test = subprocess.run([sys.executable, "-m", "pytest", "-q", "tests/test_cap.py"],
                          cwd=ROOT, capture_output=True, text=True)
    print(test.stdout, end="", flush=True)
    if test.stderr:
        print(test.stderr, file=sys.stderr)
    if test.returncode:
        raise SystemExit("Tests failed: fix errors before generating report")
    match = re.search(r"(\d+) passed", test.stdout)
    if not match:
        raise SystemExit("Could not detect pytest pass count")
    (ROOT / "test_results.json").write_text(json.dumps({"passed": int(match.group(1)), "failed": 0}, indent=2), encoding="utf-8")
    print("STEP 2/4 - CP/AP partition experiment", flush=True)
    run("run_demo.py")
    print("STEP 3/4 - Run 1000 reads per mode", flush=True)
    run("perf_cap_bench.py")
    print("STEP 4/4 - Generate PDF report", flush=True)
    run("make_report.py")
    print("\nSUCCESS: files created in the project folder:", flush=True)
    print("  demo_results.json, bench_results.json, Lab_Report_CAP.pdf", flush=True)
    print("Read README_RU.md for what to explain at the defense.", flush=True)


if __name__ == "__main__":
    main()

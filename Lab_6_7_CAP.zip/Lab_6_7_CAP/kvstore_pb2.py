"""Protobuf message classes. Self-contained equivalent to protoc output.

For ordinary development you can regenerate this file with grpcio-tools:
python -m grpc_tools.protoc -I. --python_out=. --grpc_python_out=. kvstore.proto
"""
from google.protobuf import descriptor_pb2 as _dp
from google.protobuf import descriptor_pool as _pool
from google.protobuf.internal import builder as _builder

_fd = _dp.FileDescriptorProto()
_fd.name = "kvstore.proto"
_fd.package = "kvstore"
_fd.syntax = "proto3"


def _enum(name, values):
    e = _fd.enum_type.add()
    e.name = name
    for index, value_name in enumerate(values):
        v = e.value.add()
        v.name = value_name
        v.number = index


def _message(name, fields):
    m = _fd.message_type.add()
    m.name = name
    for field_name, number, kind, repeated, linked_type in fields:
        f = m.field.add()
        f.name = field_name
        f.number = number
        f.type = kind
        f.label = 3 if repeated else 1
        if linked_type:
            f.type_name = ".kvstore." + linked_type


def _service(name, endpoints):
    svc = _fd.service.add()
    svc.name = name
    for method_name, request, reply in endpoints:
        method = svc.method.add()
        method.name = method_name
        method.input_type = ".kvstore." + request
        method.output_type = ".kvstore." + reply


_STRING, _UINT32, _UINT64, _BOOL, _ENUM, _MESSAGE = 9, 13, 4, 8, 14, 11

def F(name, idx, kind, link=None, repeated=False):
    return name, idx, kind, repeated, link

_enum("ReadConsistency", ["LINEARIZABLE", "FOLLOWER_STALE"])
_enum("WriteStrategy", ["QUORUM_CP", "ALWAYS_AP"])
_message("GetRequest", [F("key", 1, _STRING), F("consistency", 2, _ENUM, "ReadConsistency"), F("max_staleness_ms", 3, _UINT32)])
_message("GetReply", [F("value", 1, _STRING), F("found", 2, _BOOL), F("read_timestamp", 3, _UINT64), F("is_stale", 4, _BOOL)])
_message("PutRequest", [F("key", 1, _STRING), F("value", 2, _STRING), F("idempotency_key", 3, _STRING), F("strategy", 4, _ENUM, "WriteStrategy"), F("timestamp", 5, _UINT64)])
_message("PutReply", [F("success", 1, _BOOL), F("acks_received", 2, _UINT32), F("error_message", 3, _STRING)])
_message("Entry", [F("key", 1, _STRING), F("value", 2, _STRING), F("timestamp", 3, _UINT64), F("origin", 4, _STRING)])
_message("ReplicaWrite", [F("entry", 1, _MESSAGE, "Entry")])
_message("ReplicaKey", [F("key", 1, _STRING)])
_message("Ack", [F("ok", 1, _BOOL)])
_message("PartitionRequest", [F("isolate_c", 1, _BOOL)])
_message("PingRequest", [F("sender", 1, _STRING)])
_message("SnapshotRequest", [F("entries", 1, _MESSAGE, "Entry", True)])
_message("SnapshotReply", [F("entries", 1, _MESSAGE, "Entry", True)])
_service("KeyValueStore", [("Get", "GetRequest", "GetReply"), ("Put", "PutRequest", "PutReply")])
_service("ReplicaControl", [("ApplyReplica", "ReplicaWrite", "Ack"), ("SetPartition", "PartitionRequest", "Ack"), ("Ping", "PingRequest", "Ack"), ("SyncSnapshot", "SnapshotRequest", "SnapshotReply")])

DESCRIPTOR = _pool.Default().AddSerializedFile(_fd.SerializeToString())
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, globals())
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, "kvstore_pb2", globals())
